package kr.human.mvc08.vo;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

/*

	idx NUMBER PRIMARY KEY,  -- 키필드
	REF NUMBER DEFAULT 0,  -- 원본글 번호
	seq NUMBER DEFAULT 0,  -- 표시 순서
	lev NUMBER DEFAULT 0,  -- 몇 단계 답변이냐
	name varchar2(100) NOT NULL,
	password varchar2(100) NOT NULL,
	content varchar2(4000) NOT NULL,
	regDate Timestamp DEFAULT sysdate,
	ip varchar2(50) NOT NULL,
	del char(1) DEFAULT 'N'	

 */

@Data
@XmlRootElement
public class GuestVO {
	private int idx;
	private int ref;
	private int seq;
	private int lev;
	private String name;
	private String password;
	private String content;
	private Date regDate;
	private String ip;
	private String del;
	
}
