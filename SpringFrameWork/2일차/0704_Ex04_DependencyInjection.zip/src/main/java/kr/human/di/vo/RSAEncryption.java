package kr.human.di.vo;

public class RSAEncryption implements Encryption{
	 
    public void encryptData() {
        System.out.println("Encrypting data using RSA Encryption");
    }
}