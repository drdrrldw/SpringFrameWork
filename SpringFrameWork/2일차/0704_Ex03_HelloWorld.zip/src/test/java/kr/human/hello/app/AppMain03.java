package kr.human.hello.app;


import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import kr.human.hello.vo.HelloWorld;

public class AppMain03 {
	public static void main(String[] args) {
		// 환경 설정 파일을 읽어서 컨텍스트 객체를 얻어라.
		// 컨텍스트 : 이 애플리케이션의 모든 정보를 가지고 있는 스프링 컨테이너
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("AppMain03.xml");
		
		// 스프링 컨테이너에서 필요한 객체를 찾아온다.
		HelloWorld helloWorld = context.getBean("helloWorld", HelloWorld.class);
		// 객체 사용
		// 기본적으로 싱글톤 방식으로 객체를 찾아온다.
		helloWorld.sayHello("한사람");		
		System.out.println(helloWorld.hashCode());
		
		
		HelloWorld helloWorld2 = context.getBean("helloWorld", HelloWorld.class);
		System.out.println(helloWorld2.hashCode());
		// 이름이 다른 두 객체로 해시코드를 찍었을때 해시코드가 같다. 같은 객체이므로
		// 스프링이 알아서 싱글톤으로 관리한다.
		// 
		context.close();
		
	}
}
