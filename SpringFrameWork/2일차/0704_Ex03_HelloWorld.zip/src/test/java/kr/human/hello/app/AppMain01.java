package kr.human.hello.app;

import kr.human.hello.vo.HelloWorld;
import kr.human.hello.vo.HelloWorldImpl;

// 우리가 지금까지 해온방식
public class AppMain01 {
	public static void main(String[] args) {
		HelloWorld helloWorld = new HelloWorldImpl();
		helloWorld.sayHello("한사람");
	}
}
