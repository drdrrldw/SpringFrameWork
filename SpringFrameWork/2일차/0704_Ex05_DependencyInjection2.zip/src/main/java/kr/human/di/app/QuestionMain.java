package kr.human.di.app;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import kr.human.di.vo.AnswerVO;
import kr.human.di.vo.ArrayObject;
import kr.human.di.vo.QuestionVO;
import kr.human.di.vo.SetObject;
import kr.human.di.vo.UserVO;

public class QuestionMain {
	public static void main(String[] args) {
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("QuestionVO.xml");
		
		
		QuestionVO vo1 = context.getBean("q1", QuestionVO.class);
		System.out.println(vo1);
		
		context.close();
		
		
		
				
		
	}
}
