package kr.human.di.config;

import java.util.HashSet;
import java.util.Set;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import kr.human.di.vo.SetObject;

@Configuration
public class SetObjectConfig {
		
	// 생성자를 통한 주입
	@Bean(name = "setObj1")
	public SetObject setObject1() {
		Set<String> nameSet = new HashSet<String>();
		nameSet.add("한사람");
		nameSet.add("두사람");
		nameSet.add("세사람");
		nameSet.add("한사람");
		return new SetObject(nameSet);
	}
	
	
	// Setter를 통한 주입
		@Bean(name = "setObj2")
		public SetObject setObject2() {
			Set<String> nameSet = new HashSet<String>();
			nameSet.add("한사람");
			nameSet.add("두사람");
			nameSet.add("세사람");
			nameSet.add("한사람");
			SetObject setObject = new SetObject();
			setObject.setNameSet(nameSet);
			return setObject;
		}
	
}
