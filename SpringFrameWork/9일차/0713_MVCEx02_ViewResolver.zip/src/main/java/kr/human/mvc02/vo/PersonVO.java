package kr.human.mvc02.vo;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapters;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@AllArgsConstructor
@NoArgsConstructor
@Data
@XmlRootElement(name = "person") 	// 루트태그 이름
@XmlType(propOrder = {"name", "age","gender", "birth"})
@XmlAccessorType(XmlAccessType.FIELD)
public class PersonVO {
	@XmlElement
	private String name;
	@XmlAttribute
	private int age;
	@XmlElement
	@XmlJavaTypeAdapter(GenderAdapter.class)	// XML로 만들때와 객체로 읽을때 모양 지정
	private Boolean gender;
	
	@XmlElement
	@XmlJavaTypeAdapter(BirthAdapter.class)	// XML로 만들때와 객체로 읽을때 모양 지정
	private Date birth;
}
