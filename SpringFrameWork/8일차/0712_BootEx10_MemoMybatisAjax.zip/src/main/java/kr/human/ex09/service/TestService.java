package kr.human.ex09.service;

public interface TestService {
	String today();
}
