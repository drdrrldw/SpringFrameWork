package kr.human.ex09.vo;

import lombok.Data;

@Data
public class CommonVO {
	private int idx;
	private int p;
	private int s;
	private int b;
	private String mode;	
}
