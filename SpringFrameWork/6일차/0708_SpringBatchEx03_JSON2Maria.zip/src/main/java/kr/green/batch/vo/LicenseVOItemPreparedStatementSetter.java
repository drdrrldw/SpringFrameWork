package kr.green.batch.vo;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.batch.item.database.ItemPreparedStatementSetter;

// 객체를 받아 SQL명령을 완성해주는 클래스
public class LicenseVOItemPreparedStatementSetter implements ItemPreparedStatementSetter<LicenseVO> {

	@Override
	public void setValues(LicenseVO item, PreparedStatement ps) throws SQLException {
		ps.setInt(1, item.getType());
		ps.setString(2, item.getQuestion());
		ps.setString(3, item.getAns1());
		ps.setString(4, item.getAns2());
		ps.setString(5, item.getAns3());
		ps.setString(6, item.getAns4());
		ps.setString(7, item.getAns5());
		ps.setInt(8, item.getCor1());
		ps.setInt(9, item.getCor2());
		ps.setString(10, item.getDescr());		
	}

}
