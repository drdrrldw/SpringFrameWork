DROP SEQUENCE hanjatest_idx_seq;
CREATE SEQUENCE hanjatest_idx_seq;
/*
 * 	private String d;
	private String s;
	private String n;
	private String q;
	private String e1;
	private String e2;
	private String e3;
	private String e4;
	private String a;
 */
DROP TABLE hanjatest;
CREATE TABLE hanjatest(
	idx NUMBER PRIMARY KEY,
	d   varchar2(200) NOT NULL,
	s   varchar2(200) NOT NULL,
	n   varchar2(200) NOT NULL,
	q   varchar2(200) NOT NULL,
	e1   varchar2(200),
	e2   varchar2(200),
	e3   varchar2(200),
	e4   varchar2(200),
	a    varchar2(200) NOT NULL
);

COMMIT;

SELECT * FROM hanjatest;
SELECT count(*) FROM hanjatest;



DROP SEQUENCE licenseTest_idx_seq;
CREATE SEQUENCE licenseTest_idx_seq;

DROP TABLE LICENSETEST ;
CREATE TABLE licenseTest(
	idx int PRIMARY KEY,
	TYPE int NOT NULL,
	question clob NOT NULL,
	ans1 clob ,
	ans2 clob ,
	ans3 clob ,
	ans4 clob ,
	ans5 clob,
	cor1 int NOT NULL,
	cor2 int NOT NULL,
	descr clob
);

SELECT * FROM LICENSETEST ;
SELECT * FROM LICENSETEST WHERE cor2 = 5;


