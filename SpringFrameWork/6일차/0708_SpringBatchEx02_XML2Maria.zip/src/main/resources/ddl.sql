
drop table exam_result ;

create table EXAM_RESULT(
	idx int primary key auto_increment,
	STUDENT_NAME varchar(20) not null, 
	DOB date not null, 
	PERCENTAGE FLOat(7,2) not null
);

select * from exam_result ;