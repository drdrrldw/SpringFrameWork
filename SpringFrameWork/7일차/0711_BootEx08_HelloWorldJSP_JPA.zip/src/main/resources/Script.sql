DROP SEQUENCE student_id_seq;
DROP TABLE STUDENT ;

CREATE SEQUENCE student_id_seq;


CREATE TABLE STUDENT(
	id NUMBER PRIMARY KEY,
	first_name varchar2(100) NOT NULL,
	last_name varchar2(100) NOT NULL,
	section varchar2(100) NOT NULL	
);

SELECT * FROM STUDENT s ;




