package kr.human.email.service;

import javax.mail.Message;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;

@Service("mailService")
public class MailServiceImpl implements MailService{

	@Autowired
	private JavaMailSender mailSender;

	@Override
	public void sendEmail() {
		MimeMessagePreparator preparator = new MimeMessagePreparator() {
			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
				// 보낼 메일의 양식을 만든다.
				helper.setFrom("itsungnam202111@gmail.com"); // XML 인증 계정과 반드시 같아야 한다.
				helper.setTo("ithuman202204@gmail.com");
				helper.setSubject("나 제입다.");
				
				String content = "호놀롤림ㄴ아ㅣ러ㅏ키키킹ㅋㅇ";
				helper.setText("<html><body><p>" + content + "</p><img src='cid:company-logo'></body></html>", true);
                
				
				helper.addAttachment("peng.png", new ClassPathResource("peng.png"));
				
				// 첨부파일을 메일의 내용에 붙여서 이름을 company-logo로 바꿔서 붙여준다.
				helper.addInline("company-logo", new ClassPathResource("peng.png"));
				
			}
		};
		try {
			mailSender.send(preparator);
			System.out.println("메일 발송 성공!!!");
		}catch (Exception e) {
			System.err.print("에러 : " + e.getMessage());
		}
	}

	@Override
	public void sendEmail(String toAddress, String subject, String content) {
		MimeMessagePreparator preparator = new MimeMessagePreparator() {
			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
				// 보낼 메일의 양식을 만든다.
				helper.setFrom("itsungnam202111@gmail.com"); // XML 인증 계정과 반드시 같아야 한다.
				helper.setTo(toAddress);
				helper.setSubject(subject);
				String content = "쁘리빠라ㅁ뺴리뽕";
 
                // Add an inline resource.
                // use the true flag to indicate you need a multipart message
                helper.setText("<html><body><p>" + content + "</p><img src='cid:company-logo'></body></html>", true);
                helper.addInline("company-logo", new ClassPathResource("peng.png"));
			}
		};
		try {
			mailSender.send(preparator);
			System.out.println("메일 발송 성공!!!");
		}catch (Exception e) {
			System.err.print("에러 : " + e.getMessage());
		}
		
	}
}
