 package kr.human.mvc07.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.mvc07.dao.EmpDAO;
import kr.human.mvc07.vo.EmpVO;

@Service
public class EmpService {
	
	@Autowired
	private EmpDAO empDAO;
	
	// 1. 개수 얻기
	public int selectCount() throws SQLException {
		return (int) empDAO.count();
	}	
	
	// 2. 1개 얻기
	public Optional<EmpVO> selectByIdx(int idx) throws SQLException {
		return empDAO.findById(idx);
	}
	
	// 3. 모두 얻기
	public List<EmpVO> selectList() throws SQLException{
		List<EmpVO> list = new ArrayList<EmpVO>();
		empDAO.findAll().forEach(list::add);
		return list;
		
	}
	// 4. 저장
	public void insert(EmpVO empVO) throws SQLException{
		empDAO.save(empVO);
	}
	// 5. 수정
	public EmpVO update(EmpVO empVO) throws SQLException{
		Optional<EmpVO> vo = empDAO.findById(empVO.getIdx());
		if (!vo.isPresent()) {
			return null;
		}
		EmpVO empVO2 = vo.get();
		empVO2.setName(empVO.getName());
		empVO2.setRole(empVO.getRole());
		return empDAO.save(empVO2);
	}
	// 6. 삭제
	public EmpVO delete(int idx) throws SQLException{
		Optional<EmpVO> vo = empDAO.findById(idx);
		if (!vo.isPresent()) {
			return null;
		}
		EmpVO empVO2 = vo.get();
		empDAO.delete(empVO2);
		return empVO2;
	}
	
}
