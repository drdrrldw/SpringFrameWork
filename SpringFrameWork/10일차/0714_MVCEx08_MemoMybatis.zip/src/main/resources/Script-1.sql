CREATE SEQUENCE memo_idx_seq;

CREATE  TABLE memo(
	idx NUMBER PRIMARY KEY,
	name varchar2(50) NOT NULL,
	password varchar2(50) NOT NULL,
	content varchar2(2000) NOT NULL,
	regDate timestamp  DEFAULT(sysdate) NOT NULL
);