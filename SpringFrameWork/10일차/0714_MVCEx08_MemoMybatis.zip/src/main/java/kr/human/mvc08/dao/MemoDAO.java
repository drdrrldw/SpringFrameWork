package kr.human.mvc08.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import kr.human.mvc08.vo.MemoVO;


@Mapper
public interface MemoDAO {

	// 1. 개수 얻기
	int selectCount() throws SQLException;
		
	// 2. 1개 얻기
    MemoVO selectByIdx(int idx) throws SQLException;   
	
	// 3. 모두 얻기
    List<MemoVO> selectList() throws SQLException;   
		
	// 4. 저장
	  void insert(MemoVO memoVO) throws SQLException;  
	
	// 5. 수정
	  void update(MemoVO memoVO) throws SQLException;   
	
	// 6. 삭제
	  void delete(int idx) throws SQLException;   
}
