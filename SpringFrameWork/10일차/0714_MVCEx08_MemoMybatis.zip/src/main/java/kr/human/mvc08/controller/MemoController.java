package kr.human.mvc08.controller;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import kr.human.mvc08.service.MemoService;
import kr.human.mvc08.vo.MemoVO;
import kr.human.mvc08.vo.PagingVO;

@Controller
public class MemoController {
	
	@Autowired
	private MemoService memoService;
	
	@RequestMapping(value = "/memo")
	public String memo(Model model) {
		
		model.addAttribute("list", memoService.selectList());
		model.addAttribute("totalCount", memoService.selectCount());
		
		return "memo";
	}
	
	@RequestMapping(value = "/MemoUpdate", method = RequestMethod.GET)
	public String updateGet(Model model) {
		return "redirect:/list";
	}
	
	@RequestMapping(value = "/MemoUpdate", method = RequestMethod.POST)
	public String updatePost(@ModelAttribute MemoVO memoVO,@RequestParam(defaultValue = "0")int mode, Model model) {
			switch (mode) {
				case 0:
					memoService.insert(memoVO);
				break;
				case 1:
					memoService.update(memoVO);
				break;
				case 2:
					memoService.delete(memoVO.getIdx());
				break;
				
				}
			
		return "redirect:/memo";
	}
	
	
}
