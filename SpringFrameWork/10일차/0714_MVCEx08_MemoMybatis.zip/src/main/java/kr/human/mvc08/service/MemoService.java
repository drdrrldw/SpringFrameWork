package kr.human.mvc08.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.mvc08.dao.MemoDAO;
import kr.human.mvc08.vo.MemoVO;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MemoService {

	@Autowired
	private MemoDAO memoDAO;

	// 1. 개수 얻기
	public int selectCount() {
		int count = 0;
		try {
			count = memoDAO.selectCount();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		log.info("selectCount 리턴 호출 : {}", count);
		return count;
	}

	// 2. 1개 얻기
	public MemoVO selectByIdx(int idx) {
		log.info("selectByIdx 호출 : {}", idx);
		MemoVO memoVO = null;
		try {
			memoVO = memoDAO.selectByIdx(idx);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		log.info("selectByIdx 리턴 호출 : {}", memoVO);
		return memoVO;
	}

	// 3. 모두 얻기
	public List<MemoVO> selectList() {
		log.info("selectList 호출");
		List<MemoVO> list = new ArrayList<MemoVO>();

		try {
			list = memoDAO.selectList();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		log.info("selectList 리턴 호출 : {}", list);
		return list;
	}

	// 4. 저장
	public void insert(MemoVO memoVO) {
		log.info("insert 호출 : {}", memoVO);

		try {
			memoDAO.insert(memoVO);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		log.info("insert 리턴 호출");
	}

	// 5. 수정
	public void update(MemoVO memoVO) {
		log.info("update 호출 : {}", memoVO);

		try {
			memoDAO.update(memoVO);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		log.info("update 리턴 호출");
	}

	// 6. 삭제
	public void delete(int idx) {
		log.info("delete 호출 : {}", idx);

		try {
			memoDAO.delete(idx);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		log.info("delete 리턴 호출");
	}

}
