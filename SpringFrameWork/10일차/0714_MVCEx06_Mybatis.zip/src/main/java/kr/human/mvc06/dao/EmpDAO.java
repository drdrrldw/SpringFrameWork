package kr.human.mvc06.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import kr.human.mvc06.vo.EmpVO;
import lombok.extern.slf4j.Slf4j;

@Mapper
public interface EmpDAO {

	// 1. 개수 얻기
	int selectCount() throws SQLException;
		
	// 2. 1개 얻기
	  EmpVO selectByIdx(int idx) throws SQLException;   
	
	// 3. 모두 얻기
	  List<EmpVO> selectList() throws SQLException;   
		
	// 4. 저장
	  void insert(EmpVO empVO) throws SQLException;  
	
	// 5. 수정
	  void update(EmpVO empVO) throws SQLException;   
	
	// 6. 삭제
	  void delete(int idx) throws SQLException;   
}
