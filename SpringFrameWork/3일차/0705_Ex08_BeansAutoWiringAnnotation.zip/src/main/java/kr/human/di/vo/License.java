package kr.human.di.vo;

import lombok.Data;

import lombok.NoArgsConstructor;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Component
public class License {
 
	
    private String number = "경기 22-10101010";

}
